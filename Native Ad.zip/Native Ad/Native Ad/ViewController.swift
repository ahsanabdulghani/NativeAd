//
//  ViewController.swift
//  Native Ad
//
//  Created by MacBook Pro on 20/04/2024.

import UIKit
import GoogleMobileAds

class ViewController: UIViewController {
    
    @IBOutlet weak var headlineLabel: UILabel!
    @IBOutlet weak var bodyLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var callToActionButton: UIButton!
    @IBOutlet weak var mediaView: GADMediaView!
    @IBOutlet weak var nativeAdView: GADNativeAdView!
    
    var adLoader: GADAdLoader!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadNativeAd()
    }
    
    func loadNativeAd() {
        adLoader = GADAdLoader(
            adUnitID: "ca-app-pub-3940256099942544/3986624511", // Replace with your ad unit ID
            rootViewController: self,
            adTypes: [.native],
            options: nil)
        
        adLoader.delegate = self
        adLoader.load(GADRequest())
    }
}

extension ViewController: GADNativeAdLoaderDelegate {
    func adLoader(_ adLoader: GADAdLoader, didReceive nativeAd: GADNativeAd) {
        headlineLabel.text = nativeAd.headline
        nativeAdView.headlineView = headlineLabel
        
        bodyLabel.text = nativeAd.body
        nativeAdView.bodyView = bodyLabel
        
        callToActionButton.setTitle(nativeAd.callToAction, for: .normal)
        nativeAdView.callToActionView = callToActionButton
        
        nativeAdView.nativeAd = nativeAd
        
        nativeAdView.mediaView?.mediaContent = nativeAd.mediaContent
        
        nativeAdView.mediaView = mediaView
        
        nativeAdView.isHidden = false
        if let iconImage = nativeAd.icon?.image {
            imageView.image = iconImage
            
            imageView.isHidden = false
        }
        nativeAdView.imageView = imageView
    }
    
    func adLoader(_ adLoader: GADAdLoader, didFailToReceiveAdWithError error: Error) {
        print("Failed to receive ad with error: \(error.localizedDescription)")
    }
}
